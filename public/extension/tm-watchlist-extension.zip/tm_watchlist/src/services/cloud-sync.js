import { CLOUD_CONFIG } from './cloud-config.js';
import { STORAGE_KEYS } from '../constants.js';

/**
 * CloudSync — runs ONLY in the background service worker.
 *
 * ONE-WAY: the extension is the master. After every change the watchlists are
 * uploaded to the Trading Journal website's Firestore at
 *   users/{uid}/journal/tj_watchlists  ->  { key, value: "<json string>" }
 * where the website shows them as a read-only Watchlist report page. Nothing is
 * ever read back into the extension. Uses the Firebase REST APIs (no SDK).
 * The password is never stored; only the Firebase refresh token is kept.
 */
const AUTH_KEY = 'tmCloudAuth_v1';   // { email, uid, refreshToken }
const META_KEY = 'tmCloudMeta_v1';   // { lastHash, lastSyncAt, lastError }
const CFG_KEY = 'tmCloudConfig_v1';  // { apiKey, projectId } pasted from the website's connection code
const DOC_KEY = 'tj_watchlists';
const DEBOUNCE_MS = 3000;
const MAX_VALUE_CHARS = 900000;      // Firestore doc limit is 1 MiB

let idToken = null;
let idTokenExp = 0;
let timer = null;
let chain = Promise.resolve();       // serialises uploads

const get = (k) => new Promise(r => chrome.storage.local.get([k], o => r(o[k] || null)));
const set = (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r));
const remove = (k) => new Promise(r => chrome.storage.local.remove([k], r));

/** Firebase web config: the pasted connection code wins, compiled defaults are the fallback. */
async function getCfg() {
  const saved = await get(CFG_KEY);
  const apiKey = (saved && saved.apiKey) || CLOUD_CONFIG.apiKey;
  const projectId = (saved && saved.projectId) || CLOUD_CONFIG.projectId;
  return { apiKey, projectId, ok: !!(apiKey && projectId) };
}

function friendly(code) {
  const c = String(code || '');
  if (/EMAIL_NOT_FOUND|INVALID_PASSWORD|INVALID_LOGIN_CREDENTIALS|INVALID_EMAIL/.test(c)) return 'Wrong email or password. (If you only use Google on the site, set a password first via "Forgot password".)';
  if (/TOO_MANY_ATTEMPTS/.test(c)) return 'Too many attempts. Try again later.';
  if (/USER_DISABLED/.test(c)) return 'This account is disabled.';
  return c || 'Request failed';
}

async function postJson(url, body) {
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(friendly(json?.error?.message));
  return json;
}

async function setMeta(patch) {
  const meta = (await get(META_KEY)) || {};
  await set(META_KEY, { ...meta, ...patch });
}

export const CloudSync = {
  /** Accepts the code shown on the website (Settings → Connect extension). */
  async setConfigFromCode(code) {
    try {
      const raw = String(code || '').trim().replace(/^TMW1\./, '');
      const d = JSON.parse(atob(raw));
      if (!d || typeof d.k !== 'string' || typeof d.p !== 'string' || !/^[A-Za-z0-9_-]{10,}$/.test(d.k) || !/^[a-z0-9-]{3,}$/.test(d.p)) throw new Error('bad');
      await set(CFG_KEY, { apiKey: d.k, projectId: d.p });
      return true;
    } catch (e) {
      throw new Error('That connection code is not valid. Copy it again from the website (Settings → Connect extension).');
    }
  },

  async status() {
    const auth = await get(AUTH_KEY);
    const meta = (await get(META_KEY)) || {};
    const cfg = await getCfg();
    return {
      configured: cfg.ok,
      connected: !!auth,
      email: auth?.email || '',
      lastSyncAt: meta.lastSyncAt || 0,
      lastError: meta.lastError || ''
    };
  },

  async login(email, password) {
    const cfg = await getCfg();
    if (!cfg.ok) throw new Error('Paste the connection code from the website first (Settings → Connect extension).');
    const j = await postJson(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${cfg.apiKey}`,
      { email, password, returnSecureToken: true }
    );
    idToken = j.idToken;
    idTokenExp = Date.now() + (parseInt(j.expiresIn, 10) - 60) * 1000;
    await set(AUTH_KEY, { email: j.email || email, uid: j.localId, refreshToken: j.refreshToken });
    await set(META_KEY, {});                 // force a fresh upload
    await this.pushNow();
    return this.status();
  },

  async logout() {
    idToken = null; idTokenExp = 0;
    await remove(AUTH_KEY);
    await remove(META_KEY);
    return this.status();
  },

  async token() {
    if (idToken && Date.now() < idTokenExp) return idToken;
    const auth = await get(AUTH_KEY);
    if (!auth) throw new Error('Not connected');
    const cfg = await getCfg();
    const res = await fetch(`https://securetoken.googleapis.com/v1/token?key=${cfg.apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(auth.refreshToken)}`
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      await remove(AUTH_KEY);                // revoked / password changed: ask to reconnect
      throw new Error('Session expired. Please reconnect in Settings.');
    }
    idToken = j.id_token;
    idTokenExp = Date.now() + (parseInt(j.expires_in, 10) - 60) * 1000;
    if (j.refresh_token && j.refresh_token !== auth.refreshToken) {
      await set(AUTH_KEY, { ...auth, refreshToken: j.refresh_token });
    }
    return idToken;
  },

  /** Build the report payload (read by the website's Watchlist page) from the extension state. */
  async buildPayload() {
    const o = await get(STORAGE_KEYS.DATA);
    const lists = ((o && o.watchlists) || []).map(wl => ({
      name: wl.name,
      items: (wl.sections || []).flatMap(sec => (sec.symbols || []).map(s => {
        const item = { ticker: s.ticker, exchange: s.exchange || 'NSE', color: s.color || 'none' };
        if (s.note) item.note = s.note;
        if (sec.name && sec.name !== 'Main') item.section = sec.name;
        if (s.addedAt) item.addedAt = s.addedAt;
        return item;
      }))
    }));
    return JSON.stringify({ lists, uploadedAt: Date.now() });
  },

  /** Upload now (skips if nothing changed since the last successful upload). */
  pushNow() {
    chain = chain.then(() => this._push()).catch(() => ({ error: 'upload failed' }));
    return chain;
  },

  async _push() {
    const auth = await get(AUTH_KEY);
    const cfg = await getCfg();
    if (!auth || !cfg.ok) return { skipped: true };
    try {
      const payload = await this.buildPayload();
      // Compare without the timestamp so an unchanged list is never re-uploaded.
      const fingerprint = payload.replace(/,"uploadedAt":\d+\}$/, '}');
      const meta = (await get(META_KEY)) || {};
      if (meta.lastHash === fingerprint) return { skipped: true };
      if (payload.length > MAX_VALUE_CHARS) throw new Error('Watchlists are too large to sync.');

      const tok = await this.token();
      const url = `https://firestore.googleapis.com/v1/projects/${cfg.projectId}/databases/(default)/documents/users/${auth.uid}/journal/${DOC_KEY}?updateMask.fieldPaths=key&updateMask.fieldPaths=value`;
      const res = await fetch(url, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${tok}` },
        body: JSON.stringify({ fields: { key: { stringValue: DOC_KEY }, value: { stringValue: payload } } })
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j?.error?.message || `HTTP ${res.status}`);
      }
      await set(META_KEY, { lastHash: fingerprint, lastSyncAt: Date.now(), lastError: '' });
      return { ok: true };
    } catch (e) {
      await setMeta({ lastError: e.message || String(e) });
      return { error: e.message || String(e) };
    }
  },

  /** Debounced upload, called whenever the extension's data changes. */
  schedulePush() {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => { timer = null; this.pushNow(); }, DEBOUNCE_MS);
  },

  init() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[STORAGE_KEYS.DATA]) this.schedulePush();
    });
    chrome.runtime.onStartup?.addListener(() => this.pushNow());
  }
};

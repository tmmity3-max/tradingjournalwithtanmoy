// Firebase web-app config of YOUR Trading Journal site (the same values as the
// VITE_FIREBASE_* variables). These are public identifiers, not secrets —
// access is protected by firestore.rules. Fill them in once, then rebuild.
export const CLOUD_CONFIG = {
  apiKey: '',      // VITE_FIREBASE_API_KEY
  projectId: ''    // VITE_FIREBASE_PROJECT_ID
};

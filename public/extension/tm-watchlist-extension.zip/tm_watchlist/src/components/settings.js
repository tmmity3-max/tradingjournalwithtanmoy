import { Store } from '../store.js';
import { Injector } from '../injector.js';
import { UpstoxService } from '../services/upstox.js';

// Prevent TradingView's page-level keyboard shortcuts (and its symbol-search /
// text-drawing-tool hijacking) from seeing keystrokes typed/pasted into our
// Shadow DOM inputs. Every other modal in this codebase already does this;
// the Settings panel's fields were missing it.
function isolateFromPageHotkeys(el) {
  ['keydown', 'keyup', 'keypress', 'input', 'paste'].forEach(evt => el.addEventListener(evt, e => e.stopPropagation()));
}

export const SettingsComponent = {
  render(area, sidebarInstance) {
    const div = document.createElement('div');
    div.style.padding = '15px'; // Can be moved to css later if wanted
    div.innerHTML = `
            <h3>Settings</h3>
            <div style="margin-bottom:15px">
                <label><input type="checkbox" id="chk-theme" ${Store.state.settings.theme === 'dark' ? 'checked' : ''}> Dark Mode</label><br>
                <label><input type="checkbox" id="chk-wl" ${Store.state.settings.showColWatchlist ? 'checked' : ''}> Show 'WList' (Add to Watchlist) Column</label><br>
                <label><input type="checkbox" id="chk-tv" ${Store.state.settings.showColTv ? 'checked' : ''}> Show 'TrVw' (TradingView) Column</label>
                <div style="margin-top:10px; display:flex; align-items:center; gap:10px;">
                   <label for="sel-loglevel">Log Level:</label>
                   <select id="sel-loglevel" style="flex:1">
                     <option value="ERROR" ${Store.state.settings.logLevel === 'ERROR' ? 'selected' : ''}>Error</option>
                     <option value="WARN" ${Store.state.settings.logLevel === 'WARN' ? 'selected' : ''}>Warn</option>
                     <option value="INFO" ${Store.state.settings.logLevel === 'INFO' ? 'selected' : ''}>Info</option>
                     <option value="DEBUG" ${Store.state.settings.logLevel === 'DEBUG' ? 'selected' : ''}>Debug</option>
                   </select>
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Market Data (Upstox)</h4>
            <div style="margin-bottom:15px">
                <label><input type="checkbox" id="chk-live-badges" ${Store.state.settings.showLiveBadges ? 'checked' : ''}> Show prev-day-high arrow &amp; relative volume badges</label>
                <div style="margin-top:8px; display:flex; gap:5px;">
                  <input type="password" id="txt-upstox-token" placeholder="Upstox Access Token" value="${Store.state.settings.upstoxAccessToken || ''}" style="flex:1; padding:6px; border-radius:4px; border:1px solid var(--et-border,#e0e0e0); background:var(--et-bg,#fff); color:var(--et-fg,#333); font-size:12px;">
                  <button class="btn-primary" id="btn-save-upstox-token">Save</button>
                </div>
                <div style="display:flex; gap:5px; margin-top:6px; align-items:center;">
                  <button class="icon-btn" id="btn-test-upstox" style="border:1px solid var(--et-border,#e0e0e0); padding:4px 8px; font-size:11px;">Test Connection</button>
                  <span id="upstox-status" style="font-size:11px; color:#888;"></span>
                </div>
                <div style="font-size:11px; color:#888; margin-top:6px; line-height:1.4;">
                  Use either: a daily Access Token from your Upstox developer app (expires ~3:30am IST), or the long-lived <b>Analytics Token</b> from Apps &rarr; My Apps &rarr; Analytics tab (valid 1 year, no daily refresh needed). Do NOT use a <b>Sandbox</b> token — Sandbox only supports test order placement, not market data, so quotes will never load with it. Symbols not resolvable on Upstox simply won't show badges.
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Trading Journal Sync</h4>
            <div style="margin-bottom:15px">
                <div id="cloud-connected" style="display:none">
                  <div style="font-size:12px; margin-bottom:6px;">Connected as <b id="cloud-email"></b></div>
                  <div style="display:flex; gap:5px;">
                    <button class="btn-primary" id="btn-cloud-sync" style="flex:1">Sync now</button>
                    <button class="icon-btn" id="btn-cloud-logout" style="border:1px solid var(--et-border,#e0e0e0); padding:4px 8px; font-size:11px;">Disconnect</button>
                  </div>
                </div>
                <div id="cloud-form">
                  <input type="text" id="txt-cloud-code" placeholder="Connection code (from website → Settings)" style="width:100%; padding:6px; margin-bottom:5px; box-sizing:border-box; display:none;">
                  <input type="email" id="txt-cloud-email" placeholder="Trading Journal email" style="width:100%; padding:6px; margin-bottom:5px; box-sizing:border-box;">
                  <input type="password" id="txt-cloud-pass" placeholder="Password" style="width:100%; padding:6px; margin-bottom:5px; box-sizing:border-box;">
                  <button class="btn-primary" id="btn-cloud-login" style="width:100%">Connect &amp; auto-sync</button>
                </div>
                <div id="cloud-status" style="font-size:11px; color:#888; margin-top:6px; line-height:1.4;"></div>
                <div style="font-size:11px; color:#888; margin-top:6px; line-height:1.4;">
                  Your watchlists upload automatically to your Trading Journal account after every change, for reporting on the website (one-way: manage everything here in the extension). Your password is not stored.
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Data Management</h4>
            <div style="display:flex; gap:5px; margin-bottom:10px;">
                <button class="btn-primary" id="btn-export-all" style="flex:1" title="Backup all data as CSV">Backup All</button>
            </div>
            <div style="margin-top:15px">
                <label>Import (NSE:TCS, BSE:INFY - Comma or Newline)</label>
                <textarea id="import-text" placeholder="RELIANCE, NSE\nTCS, NSE"></textarea>
                <button class="btn-primary" style="margin-top:5px" id="btn-import">Import</button>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0); margin-top:15px;">
            <h4>Watchlist Actions</h4>
            <div style="display:flex; gap:5px; margin-bottom:8px;">
                <button class="btn-primary" id="btn-clear-all" style="flex:1" title="Remove all symbols from current watchlist">Clear All Stocks</button>
            </div>
            <div style="display:flex; flex-direction:column; gap:6px;">
                <label for="sel-delete-wl" style="font-size:12px; color:#888;">Select watchlist to delete:</label>
                <select id="sel-delete-wl" style="width:100%; padding:6px; border-radius:4px; border:1px solid var(--et-border,#e0e0e0); background:var(--et-bg,#fff); color:var(--et-fg,#333); font-size:12px;">
                  ${Store.state.watchlists.map(w => `<option value="${w.id}">${w.name} (${Store.getTotalSymbolCount(w)})</option>`).join('')}
                </select>
                <button class="btn-primary" id="btn-delete-wl" style="background:#e53935; border-color:#c62828" title="Delete the selected watchlist">Delete Selected Watchlist</button>
            </div>
        `;

    div.querySelector('#chk-theme').onchange = (e) => { Store.state.settings.theme = e.target.checked ? 'dark' : 'light'; Store.save(); Store.applyTheme(); };
    div.querySelector('#chk-wl').onchange = (e) => { Store.state.settings.showColWatchlist = e.target.checked; Store.save(); Injector.process(true); };
    div.querySelector('#chk-tv').onchange = (e) => { Store.state.settings.showColTv = e.target.checked; Store.save(); Injector.process(true); };
    div.querySelector('#sel-loglevel').onchange = (e) => { Store.state.settings.logLevel = e.target.value; Store.save(); };
    isolateFromPageHotkeys(div.querySelector('#sel-loglevel'));

    div.querySelector('#chk-live-badges').onchange = (e) => { Store.state.settings.showLiveBadges = e.target.checked; Store.save(); Injector.process(true); };
    isolateFromPageHotkeys(div.querySelector('#txt-upstox-token'));

    div.querySelector('#btn-save-upstox-token').onclick = () => {
      const token = div.querySelector('#txt-upstox-token').value;
      Store.setUpstoxToken(token);
      const status = div.querySelector('#upstox-status');
      status.textContent = 'Token saved.';
      status.style.color = '#4caf50';
    };

    div.querySelector('#btn-test-upstox').onclick = async () => {
      const status = div.querySelector('#upstox-status');
      status.textContent = 'Testing...';
      status.style.color = '#888';
      const result = await UpstoxService.testConnection();
      status.textContent = result.message;
      status.style.color = result.ok ? '#4caf50' : '#e53935';
    };


    // ── Trading Journal cloud sync ──
    ['#txt-cloud-email', '#txt-cloud-pass'].forEach(sel => isolateFromPageHotkeys(div.querySelector(sel)));
    const cloudUi = (st) => {
      div.querySelector('#cloud-connected').style.display = st.connected ? 'block' : 'none';
      div.querySelector('#cloud-form').style.display = st.connected ? 'none' : 'block';
      div.querySelector('#cloud-email').textContent = st.email || '';
      div.querySelector('#txt-cloud-code').style.display = (!st.configured && !st.connected) ? 'block' : 'none';
      const el = div.querySelector('#cloud-status');
      if (!st.configured) { el.textContent = 'First paste the connection code from your website (Settings → Connect extension).'; el.style.color = '#888'; }
      else if (st.lastError) { el.textContent = 'Last sync failed: ' + st.lastError; el.style.color = '#e53935'; }
      else if (st.connected && st.lastSyncAt) { el.textContent = 'Last synced ' + new Date(st.lastSyncAt).toLocaleString(); el.style.color = '#4caf50'; }
      else el.textContent = '';
    };
    const cloudCall = (msg, busyText) => new Promise(resolve => {
      const el = div.querySelector('#cloud-status');
      if (busyText) { el.textContent = busyText; el.style.color = '#888'; }
      chrome.runtime.sendMessage(msg, res => {
        if (chrome.runtime.lastError) { el.textContent = chrome.runtime.lastError.message; el.style.color = '#e53935'; return resolve(null); }
        resolve(res);
      });
    });
    cloudCall({ action: 'CLOUD_STATUS' }).then(res => { if (res && res.success) cloudUi(res.data); });
    div.querySelector('#btn-cloud-login').onclick = async () => {
      const code = div.querySelector('#txt-cloud-code').value.trim();
      if (code) {
        const cr = await cloudCall({ action: 'CLOUD_SET_CONFIG', code }, 'Checking code...');
        if (!cr || !cr.success) { const el0 = div.querySelector('#cloud-status'); el0.textContent = (cr && cr.error) || 'Invalid code'; el0.style.color = '#e53935'; return; }
        div.querySelector('#txt-cloud-code').value = '';
        cloudUi(cr.data);
      }
      const email = div.querySelector('#txt-cloud-email').value.trim();
      const pass = div.querySelector('#txt-cloud-pass').value;
      if (!email || !pass) return;
      const res = await cloudCall({ action: 'CLOUD_LOGIN', email, password: pass }, 'Connecting...');
      div.querySelector('#txt-cloud-pass').value = '';
      if (res && res.success) cloudUi(res.data);
      else if (res) { const el = div.querySelector('#cloud-status'); el.textContent = res.error || 'Failed'; el.style.color = '#e53935'; }
    };
    div.querySelector('#btn-cloud-sync').onclick = async () => {
      const res = await cloudCall({ action: 'CLOUD_SYNC_NOW' }, 'Syncing...');
      if (res && res.data) cloudUi(res.data);
    };
    div.querySelector('#btn-cloud-logout').onclick = async () => {
      const res = await cloudCall({ action: 'CLOUD_LOGOUT' });
      if (res && res.data) cloudUi(res.data);
    };

    div.querySelector('#btn-export-all').onclick = () => {
      let csv = "Ticker,Exchange,Color,Watchlist\n";
      Store.state.watchlists.forEach(wl => {
        wl.sections.forEach(sec => {
          sec.symbols.forEach(s => { csv += `${s.ticker},${s.exchange},${s.color || 'none'},${wl.name}\n`; });
        });
      });
      if (csv.trim() === "Ticker,Exchange,Color,Watchlist") {
        alert('Nothing to back up yet — all your watchlists are empty.');
        return;
      }
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'tm_watchlist_backup.csv';
      // The anchor must be attached to the page DOM (not just the Shadow DOM
      // fragment) for a.click() to reliably trigger a download on strict-CSP
      // pages like TradingView — an unattached anchor can fail silently.
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    };

    div.querySelector('#btn-import').onclick = () => {
      const txt = div.querySelector('#import-text').value;
      if (txt) {
        const count = Store.importCSV(txt);
        alert(`Imported ${count} symbols to active watchlist.`);
        sidebarInstance.currentView = 'list';
        sidebarInstance.renderContent();
      }
    };
    isolateFromPageHotkeys(div.querySelector('#import-text'));

    div.querySelector('#btn-clear-all').onclick = () => {
      const wl = Store.activeWatchlist;
      const total = Store.getTotalSymbolCount(wl);
      if (total === 0) { alert('Watchlist is already empty.'); return; }
      if (confirm(`Remove all ${total} symbols from "${wl.name}"? This cannot be undone.`)) {
        Store.clearWatchlist(wl.id);
        sidebarInstance.currentView = 'list';
        sidebarInstance.renderContent();
      }
    };

    div.querySelector('#btn-delete-wl').onclick = () => {
      const wlId = div.querySelector('#sel-delete-wl').value;
      const wl = Store.state.watchlists.find(w => w.id === wlId);
      if (!wl) return;
      if (Store.state.watchlists.length <= 1) {
        alert('Cannot delete the last watchlist.'); return;
      }
      const total = Store.getTotalSymbolCount(wl);
      if (!confirm(`Delete the watchlist "${wl.name}" (${total} symbols)? This cannot be undone.`)) return;
      if (!confirm(`Are you absolutely sure? "${wl.name}" and all its symbols will be permanently deleted.`)) return;
      Store.deleteWatchlist(wl.id);
      sidebarInstance.currentView = 'list';
      sidebarInstance.renderContent();
    };
    isolateFromPageHotkeys(div.querySelector('#sel-delete-wl'));

    area.appendChild(div);
  }
};

import { Store } from '../store.js';
import { Injector } from '../injector.js';
import { UpstoxService } from '../services/upstox.js';

// Prevent TradingView's page-level keyboard shortcuts (and its symbol-search /
// text-drawing-tool hijacking) from seeing keystrokes typed/pasted into our
// Shadow DOM inputs. Every other modal in this codebase already does this;
// the Settings panel's fields were missing it.
function isolateFromPageHotkeys(el) {
  ['keydown', 'keyup', 'keypress', 'input', 'paste'].forEach(evt => el.addEventListener(evt, e => e.stopPropagation()));
}

export const SettingsComponent = {
  render(area, sidebarInstance) {
    const div = document.createElement('div');
    div.style.padding = '15px'; // Can be moved to css later if wanted
    div.innerHTML = `
            <h3>Settings</h3>
            <div style="margin-bottom:15px">
                <label><input type="checkbox" id="chk-theme" ${Store.state.settings.theme === 'dark' ? 'checked' : ''}> Dark Mode</label><br>
                <label><input type="checkbox" id="chk-wl" ${Store.state.settings.showColWatchlist ? 'checked' : ''}> Show 'WList' (Add to Watchlist) Column</label><br>
                <label><input type="checkbox" id="chk-tv" ${Store.state.settings.showColTv ? 'checked' : ''}> Show 'TrVw' (TradingView) Column</label>
                <div style="margin-top:10px; display:flex; align-items:center; gap:10px;">
                   <label for="sel-loglevel">Log Level:</label>
                   <select id="sel-loglevel" style="flex:1">
                     <option value="ERROR" ${Store.state.settings.logLevel === 'ERROR' ? 'selected' : ''}>Error</option>
                     <option value="WARN" ${Store.state.settings.logLevel === 'WARN' ? 'selected' : ''}>Warn</option>
                     <option value="INFO" ${Store.state.settings.logLevel === 'INFO' ? 'selected' : ''}>Info</option>
                     <option value="DEBUG" ${Store.state.settings.logLevel === 'DEBUG' ? 'selected' : ''}>Debug</option>
                   </select>
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Market Data (Upstox)</h4>
            <div style="margin-bottom:15px">
                <label><input type="checkbox" id="chk-live-badges" ${Store.state.settings.showLiveBadges ? 'checked' : ''}> Show prev-day-high arrow &amp; relative volume badges</label>
                <div style="margin-top:8px; display:flex; gap:5px;">
                  <input type="password" id="txt-upstox-token" placeholder="Upstox Access Token" value="${Store.state.settings.upstoxAccessToken || ''}" style="flex:1; padding:6px; border-radius:4px; border:1px solid var(--et-border,#e0e0e0); background:var(--et-bg,#fff); color:var(--et-fg,#333); font-size:12px;">
                  <button class="btn-primary" id="btn-save-upstox-token">Save</button>
                </div>
                <div style="display:flex; gap:5px; margin-top:6px; align-items:center;">
                  <button class="icon-btn" id="btn-test-upstox" style="border:1px solid var(--et-border,#e0e0e0); padding:4px 8px; font-size:11px;">Test Connection</button>
                  <span id="upstox-status" style="font-size:11px; color:#888;"></span>
                </div>
                <div style="font-size:11px; color:#888; margin-top:6px; line-height:1.4;">
                  Use either: a daily Access Token from your Upstox developer app (expires ~3:30am IST), or the long-lived <b>Analytics Token</b> from Apps &rarr; My Apps &rarr; Analytics tab (valid 1 year, no daily refresh needed). Do NOT use a <b>Sandbox</b> token — Sandbox only supports test order placement, not market data, so quotes will never load with it. Symbols not resolvable on Upstox simply won't show badges.
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Website Sync</h4>
            <div style="margin-bottom:15px">
                <div id="ws-status" style="font-size:12px; color:#888; margin-bottom:8px;">Checking...</div>
                <div id="ws-connect-box">
                  <textarea id="ws-code" placeholder="Paste connection code (TMW1.…) from your Trading Journal website" style="width:100%; min-height:56px; font-size:11px;"></textarea>
                  <button class="btn-primary" id="btn-ws-connect" style="margin-top:5px">Connect</button>
                  <div style="font-size:11px; color:#888; margin-top:6px; line-height:1.4;">On the website: gear icon (top-right) &rarr; TM Watchlist Extension &rarr; Generate connection code. Your watchlists then appear in the website's Watchlist section on every device. Treat the code like a password.</div>
                </div>
                <div id="ws-connected-box" style="display:none; gap:5px;">
                  <button class="btn-primary" id="btn-ws-sync" style="flex:1">Sync now</button>
                  <button class="btn-primary" id="btn-ws-disconnect" style="flex:1; background:#e53935; border-color:#c62828">Disconnect</button>
                </div>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0);">
            <h4>Data Management</h4>
            <div style="display:flex; gap:5px; margin-bottom:10px;">
                <button class="btn-primary" id="btn-export-all" style="flex:1" title="Backup all data as CSV">Backup All</button>
            </div>
            <div style="margin-top:15px">
                <label>Import (NSE:TCS, BSE:INFY - Comma or Newline)</label>
                <textarea id="import-text" placeholder="RELIANCE, NSE\nTCS, NSE"></textarea>
                <button class="btn-primary" style="margin-top:5px" id="btn-import">Import</button>
            </div>
            <hr style="border:0; border-top:1px solid var(--et-border, #e0e0e0); margin-top:15px;">
            <h4>Watchlist Actions</h4>
            <div style="display:flex; gap:5px; margin-bottom:8px;">
                <button class="btn-primary" id="btn-clear-all" style="flex:1" title="Remove all symbols from current watchlist">Clear All Stocks</button>
            </div>
            <div style="display:flex; flex-direction:column; gap:6px;">
                <label for="sel-delete-wl" style="font-size:12px; color:#888;">Select watchlist to delete:</label>
                <select id="sel-delete-wl" style="width:100%; padding:6px; border-radius:4px; border:1px solid var(--et-border,#e0e0e0); background:var(--et-bg,#fff); color:var(--et-fg,#333); font-size:12px;">
                  ${Store.state.watchlists.map(w => `<option value="${w.id}">${w.name} (${Store.getTotalSymbolCount(w)})</option>`).join('')}
                </select>
                <button class="btn-primary" id="btn-delete-wl" style="background:#e53935; border-color:#c62828" title="Delete the selected watchlist">Delete Selected Watchlist</button>
            </div>
        `;

    div.querySelector('#chk-theme').onchange = (e) => { Store.state.settings.theme = e.target.checked ? 'dark' : 'light'; Store.save(); Store.applyTheme(); };
    div.querySelector('#chk-wl').onchange = (e) => { Store.state.settings.showColWatchlist = e.target.checked; Store.save(); Injector.process(true); };
    div.querySelector('#chk-tv').onchange = (e) => { Store.state.settings.showColTv = e.target.checked; Store.save(); Injector.process(true); };
    div.querySelector('#sel-loglevel').onchange = (e) => { Store.state.settings.logLevel = e.target.value; Store.save(); };
    isolateFromPageHotkeys(div.querySelector('#sel-loglevel'));

    div.querySelector('#chk-live-badges').onchange = (e) => { Store.state.settings.showLiveBadges = e.target.checked; Store.save(); Injector.process(true); };
    isolateFromPageHotkeys(div.querySelector('#txt-upstox-token'));

    div.querySelector('#btn-save-upstox-token').onclick = () => {
      const token = div.querySelector('#txt-upstox-token').value;
      Store.setUpstoxToken(token);
      const status = div.querySelector('#upstox-status');
      status.textContent = 'Token saved.';
      status.style.color = '#4caf50';
    };

    div.querySelector('#btn-test-upstox').onclick = async () => {
      const status = div.querySelector('#upstox-status');
      status.textContent = 'Testing...';
      status.style.color = '#888';
      const result = await UpstoxService.testConnection();
      status.textContent = result.message;
      status.style.color = result.ok ? '#4caf50' : '#e53935';
    };

    // ── Website Sync (extension -> Trading Journal website) ──
    const wsSend = (msg) => new Promise((resolve) => {
      try { chrome.runtime.sendMessage(msg, (r) => resolve(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : r)); }
      catch (e) { resolve({ ok: false, error: String(e && e.message || e) }); }
    });
    const wsAgo = (ts) => {
      if (!ts) return 'never';
      const m = Math.round((Date.now() - ts) / 60000);
      return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago';
    };
    const wsRefresh = async () => {
      const st = await wsSend({ action: 'WS_STATUS' });
      const status = div.querySelector('#ws-status');
      const on = !!(st && st.connected);
      div.querySelector('#ws-connect-box').style.display = on ? 'none' : 'block';
      div.querySelector('#ws-connected-box').style.display = on ? 'flex' : 'none';
      if (!on) { status.textContent = 'Not connected.'; status.style.color = '#888'; return; }
      status.textContent = 'Connected' + (st.email ? ' as ' + st.email : '') + ' · last sync ' + wsAgo(st.lastSyncAt) + (st.lastError ? ' · ' + st.lastError : '');
      status.style.color = st.lastError ? '#e53935' : '#4caf50';
    };
    isolateFromPageHotkeys(div.querySelector('#ws-code'));
    div.querySelector('#btn-ws-connect').onclick = async () => {
      const status = div.querySelector('#ws-status');
      status.textContent = 'Connecting...'; status.style.color = '#888';
      const r = await wsSend({ action: 'WS_CONNECT', code: div.querySelector('#ws-code').value });
      if (!r || !r.ok) { await wsRefresh(); status.textContent = (r && r.error) || 'Could not connect.'; status.style.color = '#e53935'; return; }
      div.querySelector('#ws-code').value = '';
      await wsRefresh();
    };
    div.querySelector('#btn-ws-sync').onclick = async () => {
      const status = div.querySelector('#ws-status');
      status.textContent = 'Syncing...'; status.style.color = '#888';
      await wsSend({ action: 'WS_SYNC' });
      await wsRefresh();
    };
    div.querySelector('#btn-ws-disconnect').onclick = async () => {
      if (!confirm('Disconnect this browser from the website? Your watchlists stay in the extension; the website keeps its last synced copy.')) return;
      await wsSend({ action: 'WS_DISCONNECT' });
      await wsRefresh();
    };
    wsRefresh();

    div.querySelector('#btn-export-all').onclick = () => {
      let csv = "Ticker,Exchange,Color,Watchlist\n";
      Store.state.watchlists.forEach(wl => {
        wl.sections.forEach(sec => {
          sec.symbols.forEach(s => { csv += `${s.ticker},${s.exchange},${s.color || 'none'},${wl.name}\n`; });
        });
      });
      if (csv.trim() === "Ticker,Exchange,Color,Watchlist") {
        alert('Nothing to back up yet — all your watchlists are empty.');
        return;
      }
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'tm_watchlist_backup.csv';
      // The anchor must be attached to the page DOM (not just the Shadow DOM
      // fragment) for a.click() to reliably trigger a download on strict-CSP
      // pages like TradingView — an unattached anchor can fail silently.
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    };

    div.querySelector('#btn-import').onclick = () => {
      const txt = div.querySelector('#import-text').value;
      if (txt) {
        const count = Store.importCSV(txt);
        alert(`Imported ${count} symbols to active watchlist.`);
        sidebarInstance.currentView = 'list';
        sidebarInstance.renderContent();
      }
    };
    isolateFromPageHotkeys(div.querySelector('#import-text'));

    div.querySelector('#btn-clear-all').onclick = () => {
      const wl = Store.activeWatchlist;
      const total = Store.getTotalSymbolCount(wl);
      if (total === 0) { alert('Watchlist is already empty.'); return; }
      if (confirm(`Remove all ${total} symbols from "${wl.name}"? This cannot be undone.`)) {
        Store.clearWatchlist(wl.id);
        sidebarInstance.currentView = 'list';
        sidebarInstance.renderContent();
      }
    };

    div.querySelector('#btn-delete-wl').onclick = () => {
      const wlId = div.querySelector('#sel-delete-wl').value;
      const wl = Store.state.watchlists.find(w => w.id === wlId);
      if (!wl) return;
      if (Store.state.watchlists.length <= 1) {
        alert('Cannot delete the last watchlist.'); return;
      }
      const total = Store.getTotalSymbolCount(wl);
      if (!confirm(`Delete the watchlist "${wl.name}" (${total} symbols)? This cannot be undone.`)) return;
      if (!confirm(`Are you absolutely sure? "${wl.name}" and all its symbols will be permanently deleted.`)) return;
      Store.deleteWatchlist(wl.id);
      sidebarInstance.currentView = 'list';
      sidebarInstance.renderContent();
    };
    isolateFromPageHotkeys(div.querySelector('#sel-delete-wl'));

    area.appendChild(div);
  }
};

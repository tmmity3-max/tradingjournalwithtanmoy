/**
 * WebsiteSync — pushes the extension's watchlists to the user's Trading Journal website
 * (Firestore) so they show up in the website's Watchlist section on every device.
 *
 *  • One-way: extension -> website. The website is a read-only report.
 *  • Runs in the background service worker (not part of the content-script bundle).
 *  • Auth: a "connection code" generated on the website (gear icon -> TM Watchlist Extension).
 *    It carries the Firebase public identifiers and a refresh token for the user's account;
 *    the refresh token is exchanged for short-lived ID tokens via Firebase's REST API.
 *  • Writes ONE document:  users/{uid}/journal/tj_watchlists  ->  { key, value: JSON string }
 *    (the same layout the website's journal sync already uses).
 */

const STATE_KEY = 'tmWebSync';
const DATA_KEY = 'etData_v3'; // keep in sync with STORAGE_KEYS.DATA in constants.js
const CODE_PREFIX = 'TMW1.';
const MAX_VALUE_CHARS = 900000; // Firestore documents are limited to 1 MiB

let syncing = null;

function load() {
  return new Promise((resolve) => chrome.storage.local.get([STATE_KEY], (r) => resolve(r[STATE_KEY] || null)));
}
function save(st) {
  return new Promise((resolve) => chrome.storage.local.set({ [STATE_KEY]: st }, resolve));
}
function loadData() {
  return new Promise((resolve) => chrome.storage.local.get([DATA_KEY], (r) => resolve(r[DATA_KEY] || null)));
}

/** extension state -> the website's tj_watchlists JSON ({ lists: [{ name, items: [...] }] }). */
export function buildPayload(data) {
  const lists = [];
  for (const wl of (data && data.watchlists) || []) {
    const seen = new Map();
    for (const sec of wl.sections || []) {
      for (const sym of sec.symbols || []) {
        const ticker = String(sym.ticker || '').trim().toUpperCase();
        if (!ticker) continue;
        const exchange = String(sym.exchange || 'NSE').trim().toUpperCase() || 'NSE';
        const color = ['red', 'green', 'yellow'].includes(sym.color) ? sym.color : 'none';
        const key = exchange + ':' + ticker;
        const prev = seen.get(key);
        if (!prev) seen.set(key, { ticker, exchange, color });
        else if (prev.color === 'none' && color !== 'none') prev.color = color;
      }
    }
    lists.push({ name: String(wl.name || 'Watchlist'), items: [...seen.values()] });
  }
  return JSON.stringify({ lists });
}

export function parseCode(raw) {
  const text = String(raw || '').trim();
  if (!text.startsWith(CODE_PREFIX)) throw new Error('That is not a valid connection code.');
  let obj;
  try { obj = JSON.parse(atob(text.slice(CODE_PREFIX.length))); } catch (e) { throw new Error('The connection code is damaged — copy it again.'); }
  if (!obj || obj.v !== 1 || !obj.a || !obj.p || !obj.u || !obj.r) throw new Error('The connection code is incomplete — generate a new one.');
  return { apiKey: obj.a, projectId: obj.p, uid: obj.u, email: obj.e || '', refreshToken: obj.r };
}

async function getIdToken(st) {
  if (st.idToken && st.idExp && Date.now() < st.idExp - 60000) return st.idToken;
  const res = await fetch('https://securetoken.googleapis.com/v1/token?key=' + encodeURIComponent(st.apiKey), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(st.refreshToken),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.id_token) {
    const msg = (json && json.error && json.error.message) || 'HTTP ' + res.status;
    const e = new Error(msg === 'TOKEN_EXPIRED' || msg === 'USER_DISABLED' || msg === 'INVALID_REFRESH_TOKEN'
      ? 'Connection expired — generate a new code on the website.' : 'Sign-in failed: ' + msg);
    e.fatal = true;
    throw e;
  }
  st.idToken = json.id_token;
  st.idExp = Date.now() + (parseInt(json.expires_in, 10) || 3600) * 1000;
  if (json.refresh_token) st.refreshToken = json.refresh_token;
  await save(st);
  return st.idToken;
}

async function pushValue(st, value) {
  const token = await getIdToken(st);
  const url = 'https://firestore.googleapis.com/v1/projects/' + encodeURIComponent(st.projectId)
    + '/databases/(default)/documents/users/' + encodeURIComponent(st.uid) + '/journal/tj_watchlists'
    + '?updateMask.fieldPaths=key&updateMask.fieldPaths=value';
  const res = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ fields: { key: { stringValue: 'tj_watchlists' }, value: { stringValue: value } } }),
  });
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new Error('Upload failed: ' + ((j && j.error && j.error.message) || 'HTTP ' + res.status));
  }
}

/** Push now. `force` re-uploads even if nothing changed since the last successful sync. */
export function syncNow(force = false) {
  if (syncing) return syncing;
  syncing = (async () => {
    const st = await load();
    if (!st) return { ok: false, error: 'Not connected' };
    try {
      const value = buildPayload(await loadData());
      if (value.length > MAX_VALUE_CHARS) throw new Error('Watchlists are too large to sync.');
      if (!force && st.lastValue === value && st.lastSyncAt) return { ok: true, unchanged: true };
      await pushValue(st, value);
      const fresh = (await load()) || st;
      fresh.lastValue = value;
      fresh.lastSyncAt = Date.now();
      fresh.lastError = '';
      await save(fresh);
      return { ok: true };
    } catch (e) {
      const cur = (await load()) || st;
      cur.lastError = e.message || String(e);
      await save(cur);
      return { ok: false, error: cur.lastError };
    }
  })().finally(() => { syncing = null; });
  return syncing;
}

export async function connect(code) {
  const c = parseCode(code);
  await save({ ...c, idToken: '', idExp: 0, lastSyncAt: 0, lastError: '', lastValue: '' });
  return syncNow(true);
}

export async function disconnect() {
  await new Promise((resolve) => chrome.storage.local.remove([STATE_KEY], resolve));
  return { ok: true };
}

export async function status() {
  const st = await load();
  if (!st) return { connected: false };
  return { connected: true, email: st.email || '', lastSyncAt: st.lastSyncAt || 0, lastError: st.lastError || '' };
}

/** Wire up automatic syncing (call once from the service worker). */
export function init() {
  let timer = null;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[DATA_KEY]) return;
    clearTimeout(timer);
    timer = setTimeout(() => { syncNow(false); }, 2500);
  });
  if (chrome.alarms) {
    chrome.alarms.create('tmWebSync', { periodInMinutes: 30 });
    chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'tmWebSync') syncNow(false); });
  }
  chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
    if (!req || typeof req.action !== 'string' || !req.action.startsWith('WS_')) return false;
    const run = req.action === 'WS_CONNECT' ? connect(req.code)
      : req.action === 'WS_SYNC' ? syncNow(true)
      : req.action === 'WS_DISCONNECT' ? disconnect()
      : status();
    run.then(sendResponse).catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  });
  syncNow(false); // catch up whenever the service worker wakes
}
